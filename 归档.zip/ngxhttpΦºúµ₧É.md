​	http块中的配置项拥有三个不同的级别：

* 直接隶属于http{}块内的配置称为main配置项。

* 直接隶属于server{}块内的配置项称为srv配置项。

* 直接隶属于location{}块内的配置称为loc配置项。



  ngx_http_conf_ctx_t结构体是用于存储http块配置项的数据结构体，它仅有三个成员，分别指向三个指针数组。

```go
typedef struct {
    /* 指向一个指针数组，数组中的每个成员是由所有HTTP模块的create_main_conf方法创建的存放全局配置项的结构体，
    它们存放着解析直属http{}块内的main级别的配置项参数*/
    void        **main_conf;
    /* 指向一个指针数组，数组中的每个成员是由所有HTTP模块的create_srv_conf方法创建的与server相关的结构体，
    它们或存放着main级别配置项，或存放着srv级别的配置项，这与当前的ngx_http_conf_ctx_t是在解析http{}或者server{}块时创建的有关 */
    void        **srv_conf;
    /* 指向一个指针数组，数组中的每个成员是由所有HTTP模块的create_loc_conf方法创建的与server相关的结构体，
    它们或存放着main级别配置项，或存放着srv级别的配置项，这与当前的ngx_http_conf_ctx_t是在解析http{}或者server{}或者location{}块时创建的有关 */
    void        **loc_conf;
} ngx_http_conf_ctx_t;
```

ngx_http_core_main_conf_t

ngx_http_core_srv_conf_t

ngx_http_core_loc_conf_t



ngx_http_block是框架解析http块的总入口。

```go
static ngx_command_t  ngx_http_commands[] = {

    { ngx_string("http"),
      NGX_MAIN_CONF|NGX_CONF_BLOCK|NGX_CONF_NOARGS,
      ngx_http_block,
      0,
      0,
      NULL },

      ngx_null_command
};
```

主循环调用配置文件解析器ngx_conf_parse()解析nginx.conf文件，当发现配置文件中含有http{}关键字时，HTTP框架开始启动回调函数ngx_http_block()开始http块的解析。ngx_http_block()会从nginx.conf里获取到所有http模块自己感兴趣的配置项，并通过ngx_http_module_t接口中的方法来管理所有HTTP模块的配置项(对于每一个HTTP模块，都必须实现ngx_http_module接口)。

```go
typedef struct {
    /* 在解析http{}配置项前的回调函数 */
    ngx_int_t   (*preconfiguration)(ngx_conf_t *cf);
    /* 解析完http{}配置项后的回调函数 */
    ngx_int_t   (*postconfiguration)(ngx_conf_t *cf);

    /* 创建用于HTTP全局配置项的结构体，该结构体中的成员将保存直属于http{}块的配置参数项，它会在解析main配置项前调用 */
    void       *(*create_main_conf)(ngx_conf_t *cf);
    /* 解析完main配置项后调用 */
    char       *(*init_main_conf)(ngx_conf_t *cf, void *conf);

    /* 创建用于存储可同时出现在main、srv级别配置项的结构体，该结构体中的成员与server配置相关联 */
    void       *(*create_srv_conf)(ngx_conf_t *cf);
    /* create_srv_conf产生的结构体所要解析的配置项，可能同时出现在main、srv级别中，
    merge_srv_conf方法可以把出现在main级别中配置项值合并到srv级别配置项中 */
    char       *(*merge_srv_conf)(ngx_conf_t *cf, void *prev, void *conf);

    /* 创建用于存储可同时出现在main、srv、loc级别配置项的结构体，该结构体中的成员与location配置相关联 */
    void       *(*create_loc_conf)(ngx_conf_t *cf);
    /* create_srv_conf产生的结构体所要解析的配置项，可能同时出现在main、srv、loc级别中，
    merge_srv_conf方法可以把出现在main级别中配置项值合并到loc级别配置项中 */
    char       *(*merge_loc_conf)(ngx_conf_t *cf, void *prev, void *conf);
} ngx_http_module_t;

```

ngx_http_block()源码过程：

首先创建ngx_http_conf_ctx_t结构。

```go
static char *
ngx_http_block(ngx_conf_t *cf, ngx_command_t *cmd, void *conf)
{
    char                        *rv;
    ngx_uint_t                   mi, m, s;
    ngx_conf_t                   pcf;
    ngx_http_module_t           *module;
    ngx_http_conf_ctx_t         *ctx;
    ngx_http_core_loc_conf_t    *clcf;
    ngx_http_core_srv_conf_t   **cscfp;
    ngx_http_core_main_conf_t   *cmcf;

    if (*(ngx_http_conf_ctx_t **) conf) {
        return "is duplicate";
    }

    /* the main http context */
    // 并创建ngx_http_conf_ctx_t结构
    ctx = ngx_pcalloc(cf->pool, sizeof(ngx_http_conf_ctx_t));
    if (ctx == NULL) {
        return NGX_CONF_ERROR;
    }

    *(ngx_http_conf_ctx_t **) conf = ctx;


    
```

初始化所有HTTP模块的序列号，计算http模块的数量，并根据数量给ngx_http_conf_ctx_t中的成员分配内存

```go
/* count the number of the http modules and set up their indices */
    // 计算http模块的个数，并初始化所有HTTP模块的序列号。
    ngx_http_max_module = ngx_count_modules(cf->cycle, NGX_HTTP_MODULE);


    /* the http main_conf context, it is the same in the all http contexts */

    ctx->main_conf = ngx_pcalloc(cf->pool,
                                 sizeof(void *) * ngx_http_max_module);
    if (ctx->main_conf == NULL) {
        return NGX_CONF_ERROR;
    }


    /*
     * the http null srv_conf context, it is used to merge
     * the server{}s' srv_conf's
     */

    ctx->srv_conf = ngx_pcalloc(cf->pool, sizeof(void *) * ngx_http_max_module);
    if (ctx->srv_conf == NULL) {
        return NGX_CONF_ERROR;
    }


    /*
     * the http null loc_conf context, it is used to merge
     * the server{}s' loc_conf's
     */

    ctx->loc_conf = ngx_pcalloc(cf->pool, sizeof(void *) * ngx_http_max_module);
    if (ctx->loc_conf == NULL) {
        return NGX_CONF_ERROR;
    }
```

调用每个HTTP模块的create_main_conf、create_srv_conf、create_loc_conf方法，把各HTTP模块上述3个方法返回的地址依次保存到ngx_http_conf_ctx_t结构体的3个数组中(如果某个模块没有定义相应的方法，则为NULL)。

```go
for (m = 0; cf->cycle->modules[m]; m++) {
        if (cf->cycle->modules[m]->type != NGX_HTTP_MODULE) {
            continue;
        }

        module = cf->cycle->modules[m]->ctx;
        mi = cf->cycle->modules[m]->ctx_index;

        if (module->create_main_conf) {
            ctx->main_conf[mi] = module->create_main_conf(cf);
            if (ctx->main_conf[mi] == NULL) {
                return NGX_CONF_ERROR;
            }
        }

        if (module->create_srv_conf) {
            ctx->srv_conf[mi] = module->create_srv_conf(cf);
            if (ctx->srv_conf[mi] == NULL) {
                return NGX_CONF_ERROR;
            }
        }

        if (module->create_loc_conf) {
            ctx->loc_conf[mi] = module->create_loc_conf(cf);
            if (ctx->loc_conf[mi] == NULL) {
                return NGX_CONF_ERROR;
            }
        }
    }

    pcf = *cf;
    cf->ctx = ctx;
```

调用每个HTTP模块的preconfiguration方法，如果preconfiguration返回失败，那么Nginx进程将会停止。

```go
for (m = 0; cf->cycle->modules[m]; m++) {
        if (cf->cycle->modules[m]->type != NGX_HTTP_MODULE) {
            continue;
        }

        module = cf->cycle->modules[m]->ctx;

        if (module->preconfiguration) {
            if (module->preconfiguration(cf) != NGX_OK) {
                return NGX_CONF_ERROR;
            }
        }
    }
```

设置module_type = NGX_HTTP_MODULE和cmd_type = NGX_HTTP_MAIN_CONF，让ngx_conf_parse循环解析nginx.conf文件中直属于http{...}里面的所有配置项

```go
/* parse inside the http{} block */
    cf->module_type = NGX_HTTP_MODULE;
    cf->cmd_type = NGX_HTTP_MAIN_CONF;
    rv = ngx_conf_parse(cf, NULL);

    if (rv != NGX_CONF_OK) {
        goto failed;
    }
```

配置文件解析器调用ngx_conf_read_token读取配置项，在读取到一个配置项后，调用ngx_conf_handler函数检查是否有模块对该配置项感兴趣。

```go
char *
ngx_conf_parse(ngx_conf_t *cf, ngx_str_t *filename)
{
    ...

    if (filename) {
    	...
    }
    for ( ;; ) {
        rc = ngx_conf_read_token(cf);
        ...
        rc = ngx_conf_handler(cf, rc);

        if (rc == NGX_ERROR) {
            goto failed;
        }
    }
	...
}
```

ngx_conf_handler遍历模块，匹配模块类型和指令类型。如果找到一个HTTP模块对这个配置项感兴趣，就调用ngx_command_t结构中的set方法来处理该配置项。如果set方法返回失败，那么Nginx进程会停止。

```go
static ngx_int_t
ngx_conf_handler(ngx_conf_t *cf, ngx_int_t last)
{
    ...
    name = cf->args->elts;

    found = 0;

    for (i = 0; cf->cycle->modules[i]; i++) {
        // 遍历模块，取得该模块的指令集
        cmd = cf->cycle->modules[i]->commands;
        if (cmd == NULL) {
            continue;
        }
        // 遍历指令集是否含有该指令
        for ( /* void */ ; cmd->name.len; cmd++) {

            if (name->len != cmd->name.len) {
                continue;
            }

            if (ngx_strcmp(name->data, cmd->name.data) != 0) {
                continue;
            }

            found = 1;
            // 判断模块类型cf->cycle->modules[i]是否与当前正在处理的模块类型cf->module_type匹配
            if (cf->cycle->modules[i]->type != NGX_CONF_MODULE
                && cf->cycle->modules[i]->type != cf->module_type)
            {
                continue;
            }

            /* is the directive's location right ? */
            // 判断指令类型是否匹配
            if (!(cmd->type & cf->cmd_type)) {
                continue;
            }
            
			...
            
            // 执行指令对应的功能函数 set
            rv = cmd->set(cf, cmd, conf);

            if (rv == NGX_CONF_OK) {
                return NGX_OK;
            }

            if (rv == NGX_CONF_ERROR) {
                return NGX_ERROR;
            }

            ngx_conf_log_error(NGX_LOG_EMERG, cf, 0,
                               "\"%s\" directive %s", name->data, rv);

            return NGX_ERROR;
        }
    }

    if (found) {
        ngx_conf_log_error(NGX_LOG_EMERG, cf, 0,
                           "\"%s\" directive is not allowed here", name->data);

        return NGX_ERROR;
    }
	...
}
		
```

例如发现了"server"，就会回调ngx_http_core_server来处理server{...}配置项。

```go
static ngx_command_t  ngx_http_core_commands[] = {
 	...
 	{ ngx_string("server"),
      NGX_HTTP_MAIN_CONF|NGX_CONF_BLOCK|NGX_CONF_NOARGS,
      ngx_http_core_server,
      0,
      0,
      NULL },
    ...
    { ngx_string("location"),
      NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_BLOCK|NGX_CONF_TAKE12,
      ngx_http_core_location,
      NGX_HTTP_SRV_CONF_OFFSET,
      0,
      NULL },
    ...
}

static ngx_http_module_t  ngx_http_core_module_ctx = {
    ngx_http_core_preconfiguration,        /* preconfiguration */
    ngx_http_core_postconfiguration,       /* postconfiguration */

    ngx_http_core_create_main_conf,        /* create main configuration */
    ngx_http_core_init_main_conf,          /* init main configuration */

    ngx_http_core_create_srv_conf,         /* create server configuration */
    ngx_http_core_merge_srv_conf,          /* merge server configuration */

    ngx_http_core_create_loc_conf,         /* create location configuration */
    ngx_http_core_merge_loc_conf           /* merge location configuration */
};


ngx_module_t  ngx_http_core_module = {
    NGX_MODULE_V1,
    &ngx_http_core_module_ctx,             /* module context */
    ngx_http_core_commands,                /* module directives */
    NGX_HTTP_MODULE,                       /* module type */
    NULL,                                  /* init master */
    NULL,                                  /* init module */
    NULL,                                  /* init process */
    NULL,                                  /* init thread */
    NULL,                                  /* exit thread */
    NULL,                                  /* exit process */
    NULL,                                  /* exit master */
    NGX_MODULE_V1_PADDING
};
```

​	函数ngx_http_core_server在解析server{...}之前，也会如第三步一样建立ngx_http_conf_ctx_t结构，并调用每个HTTP模块的create_srv_conf、create_loc_conf回调方法，同样将各HTTP模块返回的指针地址保存到ngx_http_conf_ctx_t对应的srv_conf和loc_conf数组中，而main_conf将指向所属的http块下的ngx_htto_core_ctx_t结构体的main_conf指针数组。

​	但HTTP模块会包含任意个server块，对于每个server块都需要建立1个ngx_http_conf_ctx_t，这些server块的都是通过main级别的ngx_http_core_main_conf_t结构体中的servers数组管理起来的。开始调用配置文件解析器来处理server{...}里面的配置项。

```go
static char *
ngx_http_core_server(ngx_conf_t *cf, ngx_command_t *cmd, void *dummy)
{
    char                        *rv;
    void                        *mconf;
    ngx_uint_t                   i;
    ngx_conf_t                   pcf;
    ngx_http_module_t           *module;
    struct sockaddr_in          *sin;
    ngx_http_conf_ctx_t         *ctx, *http_ctx;
    ngx_http_listen_opt_t        lsopt;
    ngx_http_core_srv_conf_t    *cscf, **cscfp;
    ngx_http_core_main_conf_t   *cmcf;

    ctx = ngx_pcalloc(cf->pool, sizeof(ngx_http_conf_ctx_t));
    if (ctx == NULL) {
        return NGX_CONF_ERROR;
    }
	// main_conf将指向所属的http块下的ngx_htto_core_ctx_t结构体的main_conf指针数组
    http_ctx = cf->ctx;
    ctx->main_conf = http_ctx->main_conf;

    /* the server{}'s srv_conf */
	// 而srv_conf和loc_conf都将重新分配指针数组，数组的大小为所有HTTP模块的总数。
    ctx->srv_conf = ngx_pcalloc(cf->pool, sizeof(void *) * ngx_http_max_module);
    if (ctx->srv_conf == NULL) {
        return NGX_CONF_ERROR;
    }

    /* the server{}'s loc_conf */

    ctx->loc_conf = ngx_pcalloc(cf->pool, sizeof(void *) * ngx_http_max_module);
    if (ctx->loc_conf == NULL) {
        return NGX_CONF_ERROR;
    }
    // 循环调用所有http模块的create_srv_conf和create_loc_conf方法(如果模块有实现相应的方法的话)，将返回的结构体指针按照模块序号ctx_index保存到对应的数组当中。
    for (i = 0; cf->cycle->modules[i]; i++) {
        if (cf->cycle->modules[i]->type != NGX_HTTP_MODULE) {
            continue;
        }

        module = cf->cycle->modules[i]->ctx;

        if (module->create_srv_conf) {
            mconf = module->create_srv_conf(cf);
            if (mconf == NULL) {
                return NGX_CONF_ERROR;
            }

            ctx->srv_conf[cf->cycle->modules[i]->ctx_index] = mconf;
        }

        if (module->create_loc_conf) {
            mconf = module->create_loc_conf(cf);
            if (mconf == NULL) {
                return NGX_CONF_ERROR;
            }

            ctx->loc_conf[cf->cycle->modules[i]->ctx_index] = mconf;
        }
    }


    /* the server configuration context */

    cscf = ctx->srv_conf[ngx_http_core_module.ctx_index];
    cscf->ctx = ctx;

	// 将当前server块的ngx_http_srv_conf_t结构体推入到main级别的
    cmcf = ctx->main_conf[ngx_http_core_module.ctx_index];

    cscfp = ngx_array_push(&cmcf->servers);
    if (cscfp == NULL) {
        return NGX_CONF_ERROR;
    }

    *cscfp = cscf;


    /* parse inside server{} */
    // 解析当前server{}块内的所有配置项
    pcf = *cf;
    cf->ctx = ctx;
    cf->cmd_type = NGX_HTTP_SRV_CONF;

    rv = ngx_conf_parse(cf, NULL);

    *cf = pcf;

    if (rv == NGX_CONF_OK && !cscf->listen) {
        ngx_memzero(&lsopt, sizeof(ngx_http_listen_opt_t));

        sin = &lsopt.sockaddr.sockaddr_in;

        sin->sin_family = AF_INET;
#if (NGX_WIN32)
        sin->sin_port = htons(80);
#else
        sin->sin_port = htons((getuid() == 0) ? 80 : 8000);
#endif
        sin->sin_addr.s_addr = INADDR_ANY;

        lsopt.socklen = sizeof(struct sockaddr_in);

        lsopt.backlog = NGX_LISTEN_BACKLOG;
        lsopt.rcvbuf = -1;
        lsopt.sndbuf = -1;
#if (NGX_HAVE_SETFIB)
        lsopt.setfib = -1;
#endif
#if (NGX_HAVE_TCP_FASTOPEN)
        lsopt.fastopen = -1;
#endif
        lsopt.wildcard = 1;

        (void) ngx_sock_ntop(&lsopt.sockaddr.sockaddr, lsopt.socklen,
                             lsopt.addr, NGX_SOCKADDR_STRLEN, 1);

        if (ngx_http_add_listen(cf, cscf, &lsopt) != NGX_OK) {
            return NGX_CONF_ERROR;
        }
    }

    return rv;
}

```

如果发现了location关键字，则回调ngx_http_core_location()函数解析location{}下的配置项。

```c++
static char *
ngx_http_core_location(ngx_conf_t *cf, ngx_command_t *cmd, void *dummy)
{
    char                      *rv;
    u_char                    *mod;
    size_t                     len;
    ngx_str_t                 *value, *name;
    ngx_uint_t                 i;
    ngx_conf_t                 save;
    ngx_http_module_t         *module;
    ngx_http_conf_ctx_t       *ctx, *pctx;
    ngx_http_core_loc_conf_t  *clcf, *pclcf;

    // 先建立ngx_http_conf_ctx_t结构体
    ctx = ngx_pcalloc(cf->pool, sizeof(ngx_http_conf_ctx_t));
    if (ctx == NULL) {
        return NGX_CONF_ERROR;
    }

    // pctx指向当前location的父级{}的配置上下文结构体，如server{}或者location{}
    pctx = cf->ctx;  
    // main_conf和srv_conf都将指向所属的server块下的ngx_http_conf_ct_t结构体中的main_conf和srv_conf指针数组
    ctx->main_conf = pctx->main_conf;
    ctx->srv_conf = pctx->srv_conf;
    // 而loc_conf则将指向重新分配的指针数组
    ctx->loc_conf = ngx_pcalloc(cf->pool, sizeof(void *) * ngx_http_max_module);
    if (ctx->loc_conf == NULL) {
        return NGX_CONF_ERROR;
    }

    /* 
        循环调用所有http模块的create_loc_conf方法，生成的loc级别的配置项结构体保存到当前
        location的loc_conf数组中的各自ctx_index索引处
    */ 
    for (i = 0; cf->cycle->modules[i]; i++) {
        if (cf->cycle->modules[i]->type != NGX_HTTP_MODULE) {
            continue;
        }

        module = cf->cycle->modules[i]->ctx;

        if (module->create_loc_conf) {
            ctx->loc_conf[cf->cycle->modules[i]->ctx_index] =
                                                   module->create_loc_conf(cf);
            if (ctx->loc_conf[cf->cycle->modules[i]->ctx_index] == NULL) {
                return NGX_CONF_ERROR;
            }
        }
    }

    clcf = ctx->loc_conf[ngx_http_core_module.ctx_index];
    clcf->loc_conf = ctx->loc_conf; // ???

    value = cf->args->elts;

    // 若当前location配置指令总共有三个参数, 如: location = /test
    if (cf->args->nelts == 3) {

        len = value[1].len;
        mod = value[1].data;
        name = &value[2];

        // 若第二个参数为 ‘=‘，则表示该 location 为完全匹配
        if (len == 1 && mod[0] == '=') {

            clcf->name = *name;
            clcf->exact_match = 1;  // 标志位，为 1 表示当前location为完全匹配类型

        // 若第二个参数为 "^~"，如: location ^~ /static/，则表示为对 URL 路径进行前缀匹配
        } else if (len == 2 && mod[0] == '^' && mod[1] == '~') {

            clcf->name = *name;
            clcf->noregex = 1;      // 标志位，为 1 表示不是正则匹配 

        // 若第二个参数为 "~"，如：location ~ \.(gif|jpg|png|js|css)$，则表示区分大小写的正则匹配
        } else if (len == 1 && mod[0] == '~') {

            if (ngx_http_core_regex_location(cf, clcf, name, 0) != NGX_OK) {
                return NGX_CONF_ERROR;
            }

        // 若第二个参数为 "~*"，如：location ~* \.png$，则表示为不区分大小写的正则匹配
        } else if (len == 2 && mod[0] == '~' && mod[1] == '*') {

            if (ngx_http_core_regex_location(cf, clcf, name, 1) != NGX_OK) {
                return NGX_CONF_ERROR;
            }

        // 除此之外的其他情况表示错误
        } else {
            ngx_conf_log_error(NGX_LOG_EMERG, cf, 0,
                               "invalid location modifier \"%V\"", &value[1]);
            return NGX_CONF_ERROR;
        }

    // 若当前location配置指令总共有三个参数, 如: location =/test
    } else {

        name = &value[1];

        if (name->data[0] == '=') {

            clcf->name.len = name->len - 1;
            clcf->name.data = name->data + 1;
            clcf->exact_match = 1;

        } else if (name->data[0] == '^' && name->data[1] == '~') {

            clcf->name.len = name->len - 2;
            clcf->name.data = name->data + 2;
            clcf->noregex = 1;

        } else if (name->data[0] == '~') {

            name->len--;
            name->data++;

            if (name->data[0] == '*') {

                name->len--;
                name->data++;

                if (ngx_http_core_regex_location(cf, clcf, name, 1) != NGX_OK) {
                    return NGX_CONF_ERROR;
                }

            } else {
                if (ngx_http_core_regex_location(cf, clcf, name, 0) != NGX_OK) {
                    return NGX_CONF_ERROR;
                }
            }

        } else {

            clcf->name = *name;

            if (name->data[0] == '@') {
                clcf->named = 1;
            }
        }
    }
    /* 获取父级（一般为 server{}或 location{}(嵌套location的情况)）下loc_conf数组中 
     * ngx_http_core_module 模块的上下文配置结构体 */
    pclcf = pctx->loc_conf[ngx_http_core_module.ctx_index];

    // 若当前的 location 位于另一个location内
    if (cf->cmd_type == NGX_HTTP_LOC_CONF) {

        /* nested location */

#if 0
        clcf->prev_location = pclcf;
#endif
        /* 若父级 location 为完全匹配的情况，则表示出错，因为
         * 精确匹配的location内不允许嵌套另一个location */
        if (pclcf->exact_match) {
            ngx_conf_log_error(NGX_LOG_EMERG, cf, 0,
                               "location \"%V\" cannot be inside "
                               "the exact location \"%V\"",
                               &clcf->name, &pclcf->name);
            return NGX_CONF_ERROR;
        }

        /* 
         * 若父级 location 为命名 location 的情况，则同样表示错误，
         * 因为命名 location 里也不能包含其他 location
         */
        if (pclcf->named) {
            ngx_conf_log_error(NGX_LOG_EMERG, cf, 0,
                               "location \"%V\" cannot be inside "
                               "the named location \"%V\"",
                               &clcf->name, &pclcf->name);
            return NGX_CONF_ERROR;
        }
        // 命名location只能在 server 上下文里，仅用于 server 内部跳转 
        if (clcf->named) {
            ngx_conf_log_error(NGX_LOG_EMERG, cf, 0,
                               "named location \"%V\" can be "
                               "on the server level only",
                               &clcf->name);
            return NGX_CONF_ERROR;
        }

        len = pclcf->name.len;

#if (NGX_PCRE)
        if (clcf->regex == NULL
            && ngx_filename_cmp(clcf->name.data, pclcf->name.data, len) != 0)
#else
        if (ngx_filename_cmp(clcf->name.data, pclcf->name.data, len) != 0)
#endif
        {
            ngx_conf_log_error(NGX_LOG_EMERG, cf, 0,
                               "location \"%V\" is outside location \"%V\"",
                               &clcf->name, &pclcf->name);
            return NGX_CONF_ERROR;
        }
    }

    /* 
     * 在对参数进行解析并区分出 location 类型以及做出有效性判断后，
     * 将该 location 添加到父级的 locations 队列里，这里表明是当前
     * server{} 下的所有 location 都添加到该 server{} 下的 locations 
     * 队列中进行统一管理 
     * */
    if (ngx_http_add_location(cf, &pclcf->locations, clcf) != NGX_OK) {
        return NGX_CONF_ERROR;
    }

    save = *cf;
    cf->ctx = ctx;                      // 设置配置结构体的 ctx 上下文指向当前 location{} 的上下文
    cf->cmd_type = NGX_HTTP_LOC_CONF;   // 标记接下来解析的指令位于location{}内

    // 开始解析该 location{}
    rv = ngx_conf_parse(cf, NULL);

    *cf = save;

    return rv;
}
```

配置文件解析器继续解析配置项，如果发现处理到了http{...}的尾部，返回整个HTTP框架继续处理。此时所有server都被保存在ngx_http_core_module模块的http{}块配置中的main_conf成员的servers数组中，而每个server里面的所有location(包括nested location)都按配置中出现的顺序保存在所属srv{}块配置中的loc_conf成员的locations队列中，这样就把不同级别的配置项全部关联起来了。

插图：

随后就是调用merge_srv_conf、merge_loc_conf等方法合并这些不同块中每个HTTP模块分配的数据结构。

```go
static char *
ngx_http_block(ngx_conf_t *cf, ngx_command_t *cmd, void *conf)
{
    ...
    /*
     * init http{} main_conf's, merge the server{}s' srv_conf's
     * and its location{}s' loc_conf's
     */

    cmcf = ctx->main_conf[ngx_http_core_module.ctx_index];
    cscfp = cmcf->servers.elts;

    for (m = 0; cf->cycle->modules[m]; m++) {
        if (cf->cycle->modules[m]->type != NGX_HTTP_MODULE) {
            continue;
        }

        module = cf->cycle->modules[m]->ctx;
        mi = cf->cycle->modules[m]->ctx_index;

        /* init http{} main_conf's */

        if (module->init_main_conf) {
            rv = module->init_main_conf(cf, ctx->main_conf[mi]);
            if (rv != NGX_CONF_OK) {
                goto failed;
            }
        }

        rv = ngx_http_merge_servers(cf, cmcf, module, mi);
        if (rv != NGX_CONF_OK) {
            goto failed;
        }
    }

	...
}
```



21.HTTP框架处理完毕http配置项，返回给配置文件解析器继续处理其他http{...}外的配置项。

22.配置文件解析器处理完所有配置项后告诉Nginx主循环配置项解析完毕，这是Nginx才会启动Web服务器。